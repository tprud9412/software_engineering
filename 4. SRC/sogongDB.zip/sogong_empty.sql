-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: sogong
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachedfile`
--

DROP TABLE IF EXISTS `attachedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachedfile` (
  `attachedFile_num` int NOT NULL AUTO_INCREMENT,
  `attachedFile_name` varchar(100) NOT NULL,
  `attachedFile_path` varchar(100) NOT NULL,
  `attachedFile_extension` char(5) NOT NULL,
  `attachedFile_volume` varchar(100) NOT NULL,
  `post_num` int NOT NULL,
  PRIMARY KEY (`attachedFile_num`),
  KEY `post_num_idx` (`post_num`),
  CONSTRAINT `post_num` FOREIGN KEY (`post_num`) REFERENCES `post` (`post_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachedfile`
--

LOCK TABLES `attachedfile` WRITE;
/*!40000 ALTER TABLE `attachedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor`
--

DROP TABLE IF EXISTS `instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor` (
  `instructor_num` int NOT NULL AUTO_INCREMENT,
  `instructor_id` varchar(20) DEFAULT NULL,
  `instructor_name` varchar(10) NOT NULL,
  `instructor_pw` varchar(20) NOT NULL,
  `phone_num` varchar(13) NOT NULL,
  `birth_date` varchar(8) NOT NULL,
  `qr_code` varchar(100) NOT NULL,
  PRIMARY KEY (`instructor_num`),
  UNIQUE KEY `instructor_id` (`instructor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor`
--

LOCK TABLES `instructor` WRITE;
/*!40000 ALTER TABLE `instructor` DISABLE KEYS */;
/*!40000 ALTER TABLE `instructor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lecture`
--

DROP TABLE IF EXISTS `lecture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lecture` (
  `lecture_num` int NOT NULL AUTO_INCREMENT,
  `lecture_name` varchar(45) NOT NULL,
  `lecture_event` varchar(10) NOT NULL,
  `center_code` int NOT NULL,
  `instructor_num` int NOT NULL,
  `lecture_price` int NOT NULL,
  PRIMARY KEY (`lecture_num`),
  KEY `instructor_num_idx` (`instructor_num`),
  CONSTRAINT `instructor_num_lecture` FOREIGN KEY (`instructor_num`) REFERENCES `instructor` (`instructor_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecture`
--

LOCK TABLES `lecture` WRITE;
/*!40000 ALTER TABLE `lecture` DISABLE KEYS */;
/*!40000 ALTER TABLE `lecture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locker`
--

DROP TABLE IF EXISTS `locker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locker` (
  `locker_num` int NOT NULL AUTO_INCREMENT,
  `locker_id` int NOT NULL,
  `price` int NOT NULL,
  `center_code` int NOT NULL,
  `member_num` int DEFAULT NULL,
  `instructor_num` int DEFAULT NULL,
  PRIMARY KEY (`locker_num`),
  KEY `member_num_locker_idx` (`member_num`),
  KEY `instructor_num_locker_idx` (`instructor_num`),
  CONSTRAINT `instructor_num_locker` FOREIGN KEY (`instructor_num`) REFERENCES `instructor` (`instructor_num`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `member_num_locker` FOREIGN KEY (`member_num`) REFERENCES `member` (`member_num`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locker`
--

LOCK TABLES `locker` WRITE;
/*!40000 ALTER TABLE `locker` DISABLE KEYS */;
/*!40000 ALTER TABLE `locker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_num` int NOT NULL AUTO_INCREMENT,
  `member_id` varchar(10) DEFAULT NULL,
  `member_name` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone_num` varchar(13) NOT NULL,
  `birth` varchar(8) NOT NULL,
  `adress` varchar(45) NOT NULL,
  `QR_code` varchar(45) NOT NULL,
  PRIMARY KEY (`member_num`),
  UNIQUE KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_num` int NOT NULL AUTO_INCREMENT,
  `payment_date` datetime NOT NULL,
  `payment_amount` int NOT NULL,
  `center_code` int NOT NULL,
  `member_num` int DEFAULT NULL,
  `lecture_num` int DEFAULT NULL,
  `locker_num` int DEFAULT NULL,
  `instructor_num` int DEFAULT NULL,
  `lecture_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`payment_num`),
  KEY `member_num_idx` (`member_num`),
  KEY `lecture_name_idx` (`lecture_num`),
  KEY `locker_num_payment_idx` (`locker_num`),
  KEY `instructor_num_idx` (`instructor_num`),
  KEY `lecture_name_payment_idx` (`lecture_name`),
  CONSTRAINT `instructor_num_payment` FOREIGN KEY (`instructor_num`) REFERENCES `instructor` (`instructor_num`),
  CONSTRAINT `lecture_num_payment` FOREIGN KEY (`lecture_num`) REFERENCES `lecture` (`lecture_num`),
  CONSTRAINT `locker_num_payment` FOREIGN KEY (`locker_num`) REFERENCES `locker` (`locker_num`),
  CONSTRAINT `member_num_payment` FOREIGN KEY (`member_num`) REFERENCES `member` (`member_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `post_num` int NOT NULL AUTO_INCREMENT,
  `post_name` varchar(200) NOT NULL,
  `post_content` varchar(1000) NOT NULL,
  `post_writer` varchar(100) NOT NULL,
  `post_date` datetime NOT NULL,
  `post_views` int NOT NULL,
  PRIMARY KEY (`post_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sign_up`
--

DROP TABLE IF EXISTS `sign_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sign_up` (
  `sign_up_num` int NOT NULL AUTO_INCREMENT,
  `lecture_num` int NOT NULL,
  `member_num` int NOT NULL,
  `sign_up_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sign_up_num`),
  KEY `lecture_num_idx` (`lecture_num`),
  KEY `member_num_idx` (`member_num`),
  CONSTRAINT `lecture_num_sign_up` FOREIGN KEY (`lecture_num`) REFERENCES `lecture` (`lecture_num`),
  CONSTRAINT `member_num_sign_up` FOREIGN KEY (`member_num`) REFERENCES `member` (`member_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sign_up`
--

LOCK TABLES `sign_up` WRITE;
/*!40000 ALTER TABLE `sign_up` DISABLE KEYS */;
/*!40000 ALTER TABLE `sign_up` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-19 22:38:41
