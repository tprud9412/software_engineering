-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: sogong
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachedfile`
--

DROP TABLE IF EXISTS `attachedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachedfile` (
  `attachedFile_num` int NOT NULL AUTO_INCREMENT,
  `attachedFile_name` varchar(100) NOT NULL,
  `attachedFile_path` varchar(100) NOT NULL,
  `attachedFile_extension` char(5) NOT NULL,
  `attachedFile_volume` varchar(100) NOT NULL,
  `post_num` int NOT NULL,
  PRIMARY KEY (`attachedFile_num`),
  KEY `post_num_idx` (`post_num`),
  CONSTRAINT `post_num` FOREIGN KEY (`post_num`) REFERENCES `post` (`post_num`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachedfile`
--

LOCK TABLES `attachedfile` WRITE;
/*!40000 ALTER TABLE `attachedfile` DISABLE KEYS */;
INSERT INTO `attachedfile` VALUES (1,'menual1.png','C:\\Users\\user\\Desktop\\10팀_src_2206101020_v0.3\\src\\main\\java\\Filemenual1.png','png','3020',1);
/*!40000 ALTER TABLE `attachedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor`
--

DROP TABLE IF EXISTS `instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor` (
  `instructor_num` int NOT NULL AUTO_INCREMENT,
  `instructor_id` varchar(20) DEFAULT NULL,
  `instructor_name` varchar(10) NOT NULL,
  `instructor_pw` varchar(20) NOT NULL,
  `phone_num` varchar(13) NOT NULL,
  `birth_date` varchar(8) NOT NULL,
  `qr_code` varchar(100) NOT NULL,
  PRIMARY KEY (`instructor_num`),
  UNIQUE KEY `instructor_id` (`instructor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor`
--

LOCK TABLES `instructor` WRITE;
/*!40000 ALTER TABLE `instructor` DISABLE KEYS */;
INSERT INTO `instructor` VALUES (1,'zxc345','최지성','zxc345','010-3456-7890','19990303','zxc345'),(2,'zxc456','성세경','zxc456','010-4567-8901','19990404','zxc456');
/*!40000 ALTER TABLE `instructor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lecture`
--

DROP TABLE IF EXISTS `lecture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lecture` (
  `lecture_num` int NOT NULL AUTO_INCREMENT,
  `lecture_name` varchar(45) NOT NULL,
  `lecture_event` varchar(10) NOT NULL,
  `center_code` int NOT NULL,
  `instructor_num` int NOT NULL,
  `lecture_price` int NOT NULL,
  PRIMARY KEY (`lecture_num`),
  KEY `instructor_num_idx` (`instructor_num`),
  CONSTRAINT `instructor_num_lecture` FOREIGN KEY (`instructor_num`) REFERENCES `instructor` (`instructor_num`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecture`
--

LOCK TABLES `lecture` WRITE;
/*!40000 ALTER TABLE `lecture` DISABLE KEYS */;
INSERT INTO `lecture` VALUES (1,'아침수영교실','수영',1,1,90000),(2,'오전수영교실','수영',1,1,75000),(3,'한국무용','생활체육',2,2,65000),(4,'요가교실','생활체육',2,2,42000),(5,'아쿠아로빅','생활체육',2,2,85000),(6,'헬스성인반','헬스',2,1,70000),(7,'헬스학생반','헬스',1,2,50000);
/*!40000 ALTER TABLE `lecture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locker`
--

DROP TABLE IF EXISTS `locker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locker` (
  `locker_num` int NOT NULL AUTO_INCREMENT,
  `locker_id` int NOT NULL,
  `price` int NOT NULL,
  `center_code` int NOT NULL,
  `member_num` int DEFAULT NULL,
  `instructor_num` int DEFAULT NULL,
  PRIMARY KEY (`locker_num`),
  KEY `member_num_locker_idx` (`member_num`),
  KEY `instructor_num_locker_idx` (`instructor_num`),
  CONSTRAINT `instructor_num_locker` FOREIGN KEY (`instructor_num`) REFERENCES `instructor` (`instructor_num`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `member_num_locker` FOREIGN KEY (`member_num`) REFERENCES `member` (`member_num`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locker`
--

LOCK TABLES `locker` WRITE;
/*!40000 ALTER TABLE `locker` DISABLE KEYS */;
INSERT INTO `locker` VALUES (1,1,20000,1,1,NULL),(2,2,20000,1,NULL,NULL),(3,3,20000,1,NULL,NULL),(4,4,20000,1,2,NULL),(5,5,30000,2,NULL,1),(6,6,30000,2,NULL,NULL),(7,7,30000,2,NULL,2),(8,8,30000,2,NULL,NULL);
/*!40000 ALTER TABLE `locker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_num` int NOT NULL AUTO_INCREMENT,
  `member_id` varchar(10) DEFAULT NULL,
  `member_name` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone_num` varchar(13) NOT NULL,
  `birth` varchar(8) NOT NULL,
  `adress` varchar(45) NOT NULL,
  `QR_code` varchar(45) NOT NULL,
  PRIMARY KEY (`member_num`),
  UNIQUE KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'zxc123','나영준','zxc123','010-1234-5678','19990101','주소1','zxc123'),(2,'zxc234','강대현','zxc234','010-2345-6789','19990202','주소2','zxc234');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_num` int NOT NULL AUTO_INCREMENT,
  `payment_date` datetime NOT NULL,
  `payment_amount` int NOT NULL,
  `center_code` int NOT NULL,
  `member_num` int DEFAULT NULL,
  `lecture_num` int DEFAULT NULL,
  `locker_num` int DEFAULT NULL,
  `instructor_num` int DEFAULT NULL,
  `lecture_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`payment_num`),
  KEY `member_num_idx` (`member_num`),
  KEY `lecture_name_idx` (`lecture_num`),
  KEY `locker_num_payment_idx` (`locker_num`),
  KEY `instructor_num_idx` (`instructor_num`),
  KEY `lecture_name_payment_idx` (`lecture_name`),
  CONSTRAINT `instructor_num_payment` FOREIGN KEY (`instructor_num`) REFERENCES `instructor` (`instructor_num`),
  CONSTRAINT `lecture_num_payment` FOREIGN KEY (`lecture_num`) REFERENCES `lecture` (`lecture_num`),
  CONSTRAINT `locker_num_payment` FOREIGN KEY (`locker_num`) REFERENCES `locker` (`locker_num`),
  CONSTRAINT `member_num_payment` FOREIGN KEY (`member_num`) REFERENCES `member` (`member_num`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'2022-06-21 09:03:31',90000,1,1,1,NULL,NULL,'아침수영교실'),(2,'2022-06-21 09:04:13',70000,2,1,6,NULL,NULL,'헬스성인반'),(3,'2022-06-21 09:04:35',75000,1,2,2,NULL,NULL,'오전수영교실'),(4,'2022-06-21 09:04:42',70000,2,2,6,NULL,NULL,'헬스성인반'),(5,'2022-06-21 09:09:00',20000,1,1,NULL,1,NULL,NULL),(6,'2022-06-21 09:09:15',30000,2,NULL,NULL,5,1,NULL),(7,'2022-06-21 09:09:25',30000,2,NULL,NULL,7,2,NULL),(8,'2022-06-21 09:09:41',20000,1,2,NULL,4,NULL,NULL);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `post_num` int NOT NULL AUTO_INCREMENT,
  `post_name` varchar(200) NOT NULL,
  `post_content` varchar(1000) NOT NULL,
  `post_writer` varchar(100) NOT NULL,
  `post_date` datetime NOT NULL,
  `post_views` int NOT NULL,
  PRIMARY KEY (`post_num`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'시설이용안내','시설이용안내 메뉴얼입니다.','관리자1','2022-06-21 09:07:03',0),(2,'2022/06/22 임시 휴무 안내','6월 22일은 임시 휴무입니다.','관리자1','2022-06-21 09:07:46',0);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sign_up`
--

DROP TABLE IF EXISTS `sign_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sign_up` (
  `sign_up_num` int NOT NULL AUTO_INCREMENT,
  `lecture_num` int NOT NULL,
  `member_num` int NOT NULL,
  `sign_up_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sign_up_num`),
  KEY `lecture_num_idx` (`lecture_num`),
  KEY `member_num_idx` (`member_num`),
  CONSTRAINT `lecture_num_sign_up` FOREIGN KEY (`lecture_num`) REFERENCES `lecture` (`lecture_num`),
  CONSTRAINT `member_num_sign_up` FOREIGN KEY (`member_num`) REFERENCES `member` (`member_num`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sign_up`
--

LOCK TABLES `sign_up` WRITE;
/*!40000 ALTER TABLE `sign_up` DISABLE KEYS */;
INSERT INTO `sign_up` VALUES (1,1,1,'2022-06-21 09:03:31'),(2,6,1,'2022-06-21 09:04:12'),(3,2,2,'2022-06-21 09:04:34'),(4,6,2,'2022-06-21 09:04:41');
/*!40000 ALTER TABLE `sign_up` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-21  9:11:25
